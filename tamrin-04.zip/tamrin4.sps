* Tamrin 4 - Independent t-test example (simulated Beck anxiety, 20 ACT vs 20 CBT).
DATA LIST FREE / Group Anxiety.
BEGIN DATA
1 11
1 14
1 7
1 7
1 16
1 20
1 18
1 10
1 11
1 11
1 15
1 16
1 9
1 15
1 14
1 18
1 12
1 14
1 5
1 11
2 18
2 22
2 14
2 19
2 20
2 12
2 22
2 10
2 10
2 27
2 7
2 12
2 16
2 15
2 19
2 16
2 13
2 18
2 17
2 12
END DATA.
VARIABLE LABELS Anxiety 'Beck Anxiety score'.
VALUE LABELS Group 1 'ACT' 2 'CBT'.

EXAMINE VARIABLES=Anxiety BY Group
  /PLOT NPPLOT
  /STATISTICS DESCRIPTIVES
  /NOTOTAL.

T-TEST GROUPS=Group(1 2)
  /VARIABLES=Anxiety
  /CRITERIA=CI(.95).
