# -*- coding: utf-8 -*-
# تمرین ۷ — شبیه‌سازی و تحلیل داده DASS-21 (۱۵۰ نفر)
import numpy as np                      # محاسبات عددی
import pandas as pd                     # کار با جدول داده
from scipy import stats                 # توزیع F برای فاصله اطمینان آلفا
import matplotlib; matplotlib.use("Agg")# رسم نمودار بدون صفحه نمایش
import matplotlib.pyplot as plt         # رسم نمودار

rng = np.random.default_rng(1405)       # بذر تصادفی ثابت تا نتایج تکرارپذیر باشد
N = 150                                 # تعداد شرکت‌کنندگان

# ---------- ۱. ساخت داده ----------
DEP = [3,5,10,13,16,17,21]              # گویه‌های افسردگی طبق کلید DASS-21
ANX = [2,4,7,9,15,19,20]                # گویه‌های اضطراب
STR = [1,6,8,11,12,14,18]               # گویه‌های استرس
group = rng.choice(["دانشجو","شاغل"], N)                 # گروه
gender = rng.choice(["زن","مرد"], N, p=[0.6,0.4])        # جنسیت
age = np.where(group=="دانشجو", rng.integers(18,27,N), rng.integers(24,51,N))  # سن متناسب با گروه
# سه عامل نهفته همبسته (افسردگی، اضطراب، استرس) تا گویه‌های هر زیرمقیاس با هم همبسته باشند
cov = np.array([[1,.6,.6],[.6,1,.6],[.6,.6,1]])
lat = rng.multivariate_normal([0,0,0], cov, N)
lat[group=="دانشجو"] += 0.3              # اثر کوچک: دانشجویان کمی پریشان‌تر
items = {}
for k,(lst) in enumerate([DEP,ANX,STR]):
    for q in lst:
        raw = 0.9 + 0.8*lat[:,k] + rng.normal(0,0.6,N)   # نمره پیوسته = عامل + خطا
        items[q] = np.clip(np.round(raw),0,3).astype(int)  # گرد کردن و محدود کردن به ۰ تا ۳
df = pd.DataFrame({"ID":[f"P{i:03d}" for i in range(1,N+1)],"Gender":gender,"Age":age,"Group":group})
for q in range(1,22): df[f"Q{q}"] = items[q]
# درج عمدی ۵ داده گمشده (کد ۹۹) و ۳ مقدار خارج از بازه (۵)
cells = rng.choice(N*21, 8, replace=False)
planted=[]
for j,c in enumerate(cells):
    r, q = divmod(c,21); col=f"Q{q+1}"; val = 99 if j<5 else 5
    df.loc[r,col]=val; planted.append((df.loc[r,"ID"],col,val))
df.to_excel("DASS21_raw_before_cleaning.xlsx", index=False)

# ---------- ۲. پاک‌سازی ----------
Q = [f"Q{i}" for i in range(1,22)]
report=[]
for col in Q:
    for idx,v in df[col].items():
        if v==99: report.append((df.loc[idx,"ID"],col,v,"گمشده (کد ۹۹)"))
        elif not 0<=v<=3: report.append((df.loc[idx,"ID"],col,v,"خارج از بازه ۰ تا ۳"))
clean = df.copy()
clean[Q] = clean[Q].astype(float)
clean[Q] = clean[Q].replace(99, np.nan)                    # ۹۹ پیش از هر محاسبه گمشده می‌شود
clean[Q] = clean[Q].where((clean[Q]>=0)&(clean[Q]<=3))     # مقدار خارج از بازه هم گمشده می‌شود (حذف ردیف نه)
clean["Flag"] = df["ID"].isin([r[0] for r in report]).map({True:"دارای داده مشکل‌دار",False:""})

# ---------- ۳. نمره‌گذاری ----------
def score(sub):
    s = clean[[f"Q{i}" for i in sub]]
    n_ok = s.notna().sum(axis=1)
    # اگر حداکثر یک گویه گمشده باشد، میانگین گویه‌های موجود × ۷ (جایگزینی میانگین فردی)، بعد × ۲
    return np.where(n_ok>=6, s.mean(axis=1)*7*2, np.nan)
clean["Depression"]=score(DEP); clean["Anxiety"]=score(ANX); clean["Stress"]=score(STR)
CUT = {"Depression":[9,13,20,27],"Anxiety":[7,9,14,19],"Stress":[14,18,25,33]}  # برش‌های Lovibond (1995)
LAB = ["بهنجار","خفیف","متوسط","شدید","بسیار شدید"]
def sev(x,c):
    if np.isnan(x): return ""
    return LAB[sum(x>t for t in c)]
for k,c in CUT.items(): clean[k+"_Severity"]=[sev(x,c) for x in clean[k]]
clean.to_excel("DASS21_after_cleaning_scored.xlsx", index=False)

# ---------- ۴. تحلیل ----------
def alpha(sub):
    s = clean[[f"Q{i}" for i in sub]].dropna()             # حذف فهرستی برای آلفا (مثل SPSS)
    k = s.shape[1]; n=len(s)
    a = k/(k-1)*(1 - s.var(ddof=1).sum()/s.sum(axis=1).var(ddof=1))
    # فاصله اطمینان ۹۵٪ به روش Feldt
    lo = 1-(1-a)*stats.f.ppf(.975, n-1, (n-1)*(k-1))
    hi = 1-(1-a)*stats.f.ppf(.025, n-1, (n-1)*(k-1))
    return a,lo,hi,n
rows=[]
for k,sub in zip(["Depression","Anxiety","Stress"],[DEP,ANX,STR]):
    x=clean[k].dropna(); a,lo,hi,n=alpha(sub)
    rows.append([k,len(x),x.mean(),x.std(ddof=1),x.skew(),x.kurt(),a,lo,hi,n])
desc=pd.DataFrame(rows,columns=["Scale","N","Mean","SD","Skewness","Kurtosis","Alpha","CI_low","CI_high","N_alpha"])
grp = clean.groupby("Group")[["Depression","Anxiety","Stress"]].agg(["mean","std","count"])
desc.to_csv("descriptives.csv",index=False); grp.to_csv("by_group.csv")
print(desc.round(3).to_string()); print(grp.round(2).to_string())
print("planted:",planted); print("found:",len(report))

# ---------- نمودارها ----------
fig,ax=plt.subplots(1,3,figsize=(12,3.6))
for a_,k in zip(ax,["Depression","Anxiety","Stress"]):
    a_.hist(clean[k].dropna(),bins=12,color="#5b7db1",edgecolor="white"); a_.set_title(k); a_.set_xlabel("Score"); a_.set_ylabel("Frequency")
plt.tight_layout(); plt.savefig("histograms.png",dpi=150)
fig,ax=plt.subplots(1,3,figsize=(12,3.6))
gmap={"دانشجو":"Student","شاغل":"Employed"}
for a_,k in zip(ax,["Depression","Anxiety","Stress"]):
    data=[clean.loc[clean.Group==g,k].dropna() for g in ["دانشجو","شاغل"]]
    a_.boxplot(data); a_.set_xticks([1,2],["Student","Employed"]); a_.set_title(k)
plt.tight_layout(); plt.savefig("boxplots.png",dpi=150)
pd.DataFrame(report,columns=["ID","Item","Value","Problem"]).to_csv("cleaning_report.csv",index=False)
