* Syntax pasted by SPSS 16: Analyze > Compare Means > Independent-Samples T Test (Define Groups: 2 and 1).
T-TEST GROUPS=Group(2 1)
  /MISSING=ANALYSIS
  /VARIABLES=Anx
  /CRITERIA=CI(.95).
